Ext.define('Exam.controller.Paper', {
	extend: 'Ext.app.Controller',
	stores: ["PaperList","PaperROList"],
	models: ["PaperList"],	
	refs: [{
		ref: 'tabPaperList',
		selector: 'tabpaperlist'
	},{
		ref: 'tabPaper',
		selector: 'tabpaper'
	}],
	requires: ["Exam.view.tab.PaperList","Exam.view.tab.Paper",,"Exam.view.tab.PaperROList"],
	init: function() { 
	},
	onLaunch: function() {
			
	}
});