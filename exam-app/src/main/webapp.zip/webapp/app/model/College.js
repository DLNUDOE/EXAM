Ext.define('Exam.model.College', {
    extend: 'Ext.data.Model',
    fields: [
        { name: 'cid', type: 'int' },
        { name: 'name', type: 'string' }
    ] 
});