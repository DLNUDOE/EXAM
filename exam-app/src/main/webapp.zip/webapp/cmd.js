F:
cd  apache-tomcat\webapps\project\apps\exam


sencha create jsb -a http://localhost:8080/project/apps/exam/index.html -p app.jsb3

sencha build jsb -p app.jsb3 -d ./