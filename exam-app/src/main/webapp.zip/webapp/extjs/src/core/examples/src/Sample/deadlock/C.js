Ext.define('Sample.deadlock.C', {
    extend: 'Sample.deadlock.D'
});