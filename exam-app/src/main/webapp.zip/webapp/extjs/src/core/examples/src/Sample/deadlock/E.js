Ext.define('Sample.deadlock.E', {
    extend: 'Sample.deadlock.A'
});